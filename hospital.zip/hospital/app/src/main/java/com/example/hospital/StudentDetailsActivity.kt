package com.example.hospital

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class StudentDetailsActivity : AppCompatActivity() {

    private lateinit var nameEditText: EditText
    private lateinit var mobileEditText: EditText
    private lateinit var classSpinner: Spinner
    private lateinit var genderRadioGroup: RadioGroup
    private lateinit var termsCheckBox: CheckBox
    private lateinit var submitButton: Button

    private var isUpdateMode = false
    private var originalStudentEntry: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_details)

        nameEditText = findViewById(R.id.nameEditText)
        mobileEditText = findViewById(R.id.mobileEditText)
        classSpinner = findViewById(R.id.classSpinner)
        genderRadioGroup = findViewById(R.id.genderRadioGroup)
        termsCheckBox = findViewById(R.id.termsCheckBox)
        submitButton = findViewById(R.id.submitButton)

        val classList = listOf("General", "Neurology", "Oncology", "Cardiology", "Gynecology")
        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, classList)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        classSpinner.adapter = spinnerAdapter

        // Check if this is an update
        isUpdateMode = intent.getBooleanExtra("is_update", false)
        originalStudentEntry = intent.getStringExtra("student_data")

        if (isUpdateMode && originalStudentEntry != null) {
            populateFormForUpdate(originalStudentEntry!!)
            submitButton.text = "Update Patient"
        }

        submitButton.setOnClickListener {
            val name = nameEditText.text.toString().trim()
            val mobile = mobileEditText.text.toString().trim()
            val selectedClass = classSpinner.selectedItem.toString()
            val selectedGenderId = genderRadioGroup.checkedRadioButtonId

            if (!name.matches(Regex("^[a-zA-Z\\s]+\$"))) {
                Toast.makeText(this, "Name must contain only letters.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!mobile.matches(Regex("^\\d{10}\$"))) {
                Toast.makeText(this, "Mobile number must be exactly 10 digits.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (selectedGenderId == -1) {
                Toast.makeText(this, "Please select gender.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!termsCheckBox.isChecked) {
                AlertDialog.Builder(this)
                    .setTitle("Terms Not Accepted")
                    .setMessage("Please accept the terms and conditions to proceed.")
                    .setPositiveButton("OK", null)
                    .show()
                return@setOnClickListener
            }

            val selectedGender = findViewById<RadioButton>(selectedGenderId).text.toString()
            val studentEntry = "$name | $selectedClass | $selectedGender"

            val sharedPreferences = getSharedPreferences("student_prefs", MODE_PRIVATE)
            val editor = sharedPreferences.edit()
            val studentsSet = sharedPreferences.getStringSet("students_set", mutableSetOf())?.toMutableSet() ?: mutableSetOf()

            if (isUpdateMode && originalStudentEntry != null) {
                studentsSet.remove(originalStudentEntry)
                Toast.makeText(this, "Student updated:\n$studentEntry", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Registered:\n$studentEntry", Toast.LENGTH_LONG).show()
            }

            studentsSet.add(studentEntry)
            editor.putStringSet("students_set", studentsSet)
            editor.apply()

            nameEditText.text.clear()
            mobileEditText.text.clear()
            genderRadioGroup.clearCheck()
            termsCheckBox.isChecked = false

            // Go back to registered students page
            val intent = Intent(this, RegisteredStudentsActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun populateFormForUpdate(studentData: String) {
        val parts = studentData.split(" | ")
        if (parts.size == 3) {
            nameEditText.setText(parts[0])
            val classIndex = when (parts[1]) {
                "General" -> 0
                "Neurology" -> 1
                "Oncology" -> 2
                "Cardiology" -> 3
                "Gynecology " -> 4
                else -> 0
            }
            classSpinner.setSelection(classIndex)

            when (parts[2]) {
                "Male" -> genderRadioGroup.check(R.id.maleRadioButton)
                "Female" -> genderRadioGroup.check(R.id.femaleRadioButton)
                "Other" -> genderRadioGroup.check(R.id.otherRadioButton)
            }

            termsCheckBox.isChecked = true
        }
    }
}
