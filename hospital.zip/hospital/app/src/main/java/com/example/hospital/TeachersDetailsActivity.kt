package com.example.hospital

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class TeacherDetailsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_teachers_details)

        // You can add more logic here if needed in the future
    }
}
