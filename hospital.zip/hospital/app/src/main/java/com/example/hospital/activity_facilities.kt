package com.example.hospital

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class FacilitiesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_facilities)

        // Hospital Facility Data (CardView ID, Name, Description, Image, URL)
        val facilitiesMap = listOf(
            Facility(R.id.cardEmergency, "Emergency Room", "24/7 emergency medical services.", R.drawable.emergency, "https://www.mayoclinic.org/"),
            Facility(R.id.cardICU, "Intensive Care Unit (ICU)", "Advanced critical care for serious conditions.", R.drawable.icu, "https://www.cdc.gov/icu.html"),
            Facility(R.id.cardOPD, "Outpatient Department (OPD)", "Consultations and minor procedures for patients.", R.drawable.opd, "https://www.webmd.com/"),
            Facility(R.id.cardRadiology, "Radiology Department", "X-rays, CT scans, MRIs, and ultrasounds.", R.drawable.radiology, "https://www.radiologyinfo.org/"),
            Facility(R.id.cardPharmacy, "Pharmacy", "In-house pharmacy with prescribed medications.", R.drawable.pharmacy, "https://www.fda.gov/"),
            Facility(R.id.cardLab, "Diagnostic Lab", "Comprehensive pathology and blood tests.", R.drawable.lab, "https://www.labtestsonline.org/"),
            Facility(R.id.cardMaternity, "Maternity Ward", "Specialized care for childbirth and neonatal care.", R.drawable.maternity, "https://www.marchofdimes.org/"),
            Facility(R.id.cardPhysiotherapy, "Physiotherapy", "Rehabilitation and pain management services.", R.drawable.physiotherapy, "https://www.apta.org/")
        )

        // Setting up each facility card dynamically
        facilitiesMap.forEach { facility ->
            val cardView = findViewById<CardView>(facility.cardId)
            val titleView = cardView.findViewById<TextView>(R.id.facilityTitle)
            val descView = cardView.findViewById<TextView>(R.id.facilityDescription)
            val imageView = cardView.findViewById<ImageView>(R.id.facilityImage)

            titleView.text = facility.name
            descView.text = facility.description
            imageView.setImageResource(facility.imageRes)

            cardView.setOnClickListener { openWebsite(facility.url) }
        }
    }

    // Function to open URLs
    private fun openWebsite(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        startActivity(intent)
    }

    // Data class for facilities
    data class Facility(val cardId: Int, val name: String, val description: String, val imageRes: Int, val url: String)
}
