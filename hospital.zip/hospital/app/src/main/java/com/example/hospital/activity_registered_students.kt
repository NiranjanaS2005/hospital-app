package com.example.hospital

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class RegisteredStudentsActivity : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var studentList: MutableList<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registered_students)

        listView = findViewById(R.id.listView)

        val sharedPreferences = getSharedPreferences("student_prefs", MODE_PRIVATE)
        val studentsSet = sharedPreferences.getStringSet("students_set", mutableSetOf())
        studentList = studentsSet?.toMutableList() ?: mutableListOf()

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, studentList)
        listView.adapter = adapter

        listView.setOnItemClickListener { _, _, position, _ ->
            val selectedStudent = studentList[position]

            val options = arrayOf("Update", "Delete")

            val builder = AlertDialog.Builder(this)
            builder.setTitle("Choose an option for:\n$selectedStudent")
            builder.setItems(options) { _, which ->
                when (which) {
                    0 -> updateStudent(selectedStudent)
                    1 -> deleteStudent(selectedStudent)
                }
            }
            builder.show()
        }
    }

    private fun deleteStudent(student: String) {
        val sharedPreferences = getSharedPreferences("student_prefs", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val studentsSet = sharedPreferences.getStringSet("students_set", mutableSetOf())?.toMutableSet()

        studentsSet?.remove(student)
        editor.putStringSet("students_set", studentsSet)
        editor.apply()

        Toast.makeText(this, "Patient deleted", Toast.LENGTH_SHORT).show()

        recreate() // Refresh activity to update list
    }

    private fun updateStudent(student: String) {
        val intent = Intent(this, StudentDetailsActivity::class.java)
        intent.putExtra("student_data", student)
        intent.putExtra("is_update", true)
        startActivity(intent)
    }
}
